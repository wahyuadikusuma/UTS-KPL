<div class="content-box content-page">
  <div class="container">
    <div class="breadcrumb">
      <ul>
        <li><a href="http://ppid.lampungprov.go.id">Home</a></li>
        <li><a href="http://ppid.lampungprov.go.id/profil">Profil</a></li>
      </ul>
    </div>
  </div>
  <section class="content-blank blue-section">
    <div class="container">
      <div class="row">
        <div class="col-12 col-lg-4 mb-4">
          <div class="d-flex align-items-center mb-4">
            <div class="icon-circle rgba-blue">
              <img src="http://ppid.lampungprov.go.id/assets_v1/images/icons/newspaper.png" class="img-fluid" alt="" width="20">
            </div>
            <p class="text-default font-600 mb-0">Informasi</p>
          </div>

          <ul class="nav tabs-vertical small-list without-primary flex-column" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="item active" id="informasi-profil-tab" data-toggle="tab" href="#InformasiProfil_Tabs" role="tab" aria-controls="InformasiProfil_Tabs" aria-selected="true">
                <div class="head-icon">
                  <div class="tabs-icon">
                    <img src="http://ppid.lampungprov.go.id/assets_v1/images/icons/building.png" class="img-fluid" alt="" width="50">
                  </div>
                </div>
                <span>Profil</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="item" id="informasi-tugaswewenang-tab" data-toggle="tab" href="#InformasiTugasWewenang_Tabs" role="tab" aria-controls="InformasiTugasWewenang_Tabs" aria-selected="false">
                <div class="head-icon">
                  <div class="tabs-icon">
                    <img src="http://ppid.lampungprov.go.id/assets_v1/images/icons/clipboard.png" class="img-fluid" alt="" width="50">
                  </div>
                </div>
                <span>Tugas dan Wewenang</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="item" id="informasi-struktur-tab" data-toggle="tab" href="#InformasiStruktur_Tabs" role="tab" aria-controls="InformasiStruktur_Tabs" aria-selected="false">
                <div class="head-icon">
                  <div class="tabs-icon">
                    <img src="http://ppid.lampungprov.go.id/assets_v1/images/icons/diagram.png" class="img-fluid" alt="" width="50">
                  </div>
                </div>
                <span>Struktur PPID</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="item" id="informasi-visi-tab" data-toggle="tab" href="#InformasiVisi_Tabs" role="tab" aria-controls="InformasiVisi_Tabs" aria-selected="false">
                <div class="head-icon">
                  <div class="tabs-icon">
                    <img src="http://ppid.lampungprov.go.id/assets_v1/images/icons/target.png" class="img-fluid" alt="" width="50">
                  </div>
                </div>
                <span>Visi dan Misi</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="item" id="informasi-tentangppid-tab" data-toggle="tab" href="#InformasiTentangPPID_Tabs" role="tab" aria-controls="InformasiTentangPPID_Tabs" aria-selected="false">
                <div class="head-icon">
                  <div class="tabs-icon">
                    <img src="http://ppid.lampungprov.go.id/assets_v1/images/icons/about-us.png" class="img-fluid" alt="" width="50">
                  </div>
                </div>
                <span>Tentang PPID</span>
              </a>
            </li>
          </ul>
        </div>

        <div class="col-12 col-lg-8 mb-4">
          <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="InformasiProfil_Tabs" role="tabpanel" aria-labelledby="informasi-profil-tab">
              <div class="heading-blue-rgba with-line mt-1 mb-4"><span>Profil</span></div>
              <div class="card card-md">
                            <p>SIP PPID adalah Sistem Informasi Publik Pejabat pengelola Informasi dan Dokumentasi atau dapat juga disebut sebagai e-public. SIP PPID atau e-public merupakan aplikasi pengelolaan dan pelayanan informasi untuk PPID yang dikembangkan sesuai Undang-Undang No. 14 Tahun 2008 tentang Keterbukaan Informasi Publik. E-public dirancang dengan platform hybrid - offline dan online, yang terintegrasi antara PPID Pembantu dan PPID Utama dalam sebuah entitas Badan Publik. Informasi lebih lengkap mengenai SIP PPID atau epublic dapat dilihat disini!<br><br>
              Untuk informasi lebih lanjut dan bagaimana mendapatkan aplikasi ini silahkan ke info@sip-ppid.net</p>
              </div>
            </div>

            <div class="tab-pane fade" id="InformasiTugasWewenang_Tabs" role="tabpanel" aria-labelledby="informasi-tugaswewenang-tab">
              <div class="heading-blue-rgba with-line mt-1 mb-4"><span>Tugas dan Wewenang</span></div>
              <div class="card card-md">
                                <p></p><h4>TUGAS</h4>
                <ul>
                  <li>Pengkoordinasikan dan mengkonsolidasikan pengumpulan bahan informasi dan dokumentasi dari PPID pembantu</li>
                  <li>Menyimpan, mendokumentasikan, menyediakan dan memberi pelayanan informasi kepada publik</li>
                  <li>Melakukan verifikasi bahan informasi publik</li>
                  <li>Melakukan uji konsekuensi atas informasi yang dikecualikan</li>
                  <li>Melakukan kemutakhiran informasi dan dokumentasi</li>
                  <li>Menyediakan informasi dan dokumentasi untuk diakses oleh masyarakat.</li>
                </ul>

                <h4>KEWENANGAN</h4>

                <ul>
                  <li>Menolak memberikan informasi yang dikecualikan sesuai dengan ketentuan peraturan perundang-undangan</li>
                  <li>Meminta dan memperoleh informasi dari unit kerja/komponen/satuan kerja yang menjadi cakupan kerjanya</li>
                  <li>Mengkoordinasikan pemberian pelayanan informasi dengan PPID Pembantu dan/atau Pejabat Fungsional yang menjadi cakupan kerjanya</li>
                  <li>Menentukan atau menetapkan suatu informasi dapat/tidaknya diakses oleh publik</li>
                  <li>Menugaskan PPID Pembantu dan/atau Pejabat Fungsional untuk membuat, mengumpulkan, serta memelihara informasi dan dokumentasi untuk kebutuhan organisasi.</li>
                </ul>
              <p></p>
              </div>
            </div>

            <div class="tab-pane fade" id="InformasiStruktur_Tabs" role="tabpanel" aria-labelledby="informasi-struktur-tab">
              <div class="heading-blue-rgba with-line mt-1 mb-4"><span>Struktur PPID</span></div>
              <div class="card card-md">
                                <p align="center"><img src="http://ppid.lampungprov.go.id/images/struktur-ppid.jpg"></p>
              </div>
            </div>

            <div class="tab-pane fade" id="InformasiVisi_Tabs" role="tabpanel" aria-labelledby="informasi-visi-tab">
              <div class="heading-blue-rgba with-line mt-1 mb-4"><span>Visi dan Misi</span></div>
              <div class="card card-md">
                                <p></p><h4>VISI</h4>
                &nbsp; &nbsp; &nbsp; &nbsp;Terwujudnya sistem politik yang demokratis, pemerintah yang desentralistrik, pembangunan daerah yang berkelanjutan, serta keberdayaan masyarakat yang partisipatif dengan didukung sumber daya aparatur yang profesional dalam wadah Negara Kesatuan Republik Indonesia.

                <h4>MISI</h4>

                Menetapkan Kebijaksanaan Nasional dan memfasilitasi penyelenggara pemerintah dalam upaya :

                <ul>
                  <li>Memperkuat Keutuhan NKRI serta memantapkan sistem politik dalam negeri yang demokratis</li>
                  <li>Memantapkan penyelenggaraan tugas-tugas pemerintah umum</li>
                  <li>Memantapkan efektifitas dan efisiensi penyelenggaraan pemerintahan yang desentralistik</li>
                  <li>Mengembangkan keserasian hubungan pusat-daerah, antara daerah dan antar kawasan secara kemandirian daerah dalam pengelolaan pembangunan secara berkelanjutan</li>
                  <li>Memperkuat otonomi desa dan meningkatkan keberdayaan masyarakat dalam aspek ekonomi, sosial dan budaya</li>
                  <li>Mewujudkan tata pemerintahan yang baik, bersih dan berwibawa</li>
                </ul>
              <p></p>
              </div>
            </div>

            <div class="tab-pane fade" id="InformasiTentangPPID_Tabs" role="tabpanel" aria-labelledby="informasi-tentangppid-tab">
              <div class="heading-blue-rgba with-line mt-1 mb-4"><span>Tentang PPID</span></div>
              <div class="card card-md">
                <p>Kabag Perencanaan, Setditjen Keuangan Daerah, Wisnu Hidayat, kepada Media Keuangan Daerah, di Jakarta, menilai undang-undang tersebut harus disikapi oleh seluruh instansi pemerintah terkait. “Artinya, ketika UU ini sudah diberlakukan maka Badan Publik termasuk Kementerian Dalam Negeri (Kemendagri) dan pemerintah daerah agar mulai melakukan keterbukaan informasi, yang memang diminta oleh publik,” ujur Wisnu. Pasal 7 UU No. 14/2008 mengamatkan bahwa Badan Publik wajib menyediakan, memberikan dan/atau menerbitkan Informasi Publik yang berada di bawah kewenangannya kepada Pemohon Informasi Publik, selain informasi yang dikecualikan sesuai dengan ketentuan. Badan Publik wajib menyediakan Informasi Publik yang akurat, benar, dan tidak menyesatkan.</p>

<p style="text-align:justify">Untuk melaksanakan kewajiban tersebut, Badan Publik harus membangun dan mengembangkan sistem informasi dan dokumentasi untuk mengelola Informasi Publik secara baik dan efisien sehingga dapat diakses dengan mudah. Selanjutnya, Badan Publik wajib membuat pertimbangan secara tertulis setiap kebijakan yang diambil untuk memenuhi hak setiap orang atas Informasi Publik. Pertimbangan tersebut antara lain memuat pertimbangan politik, ekonomi, sosial, budaya, dan/atau pertahanan dan keamanan negara. Dalam rangka memenuhi kewajiban tersebut Badan Publik dapat memanfaatkan sarana dan/atau media elektronik dan non elektronik.</p>

<p style="text-align:justify">Selain kewajiban tersebut, UU tersebut juga mengamanatkan bahwa setiap Badan Publik wajib mengumumkan Informasi Publik secara berkala, yang meliputi informasi yang terkait dengan Badan Publik; informasi mengenai kegiatan dan kinerja Badan Publik terkait; informasi mengenai laporan keuangan; dan/atau informasi lain yang diatur dalam peraturan perundang-undangan. Kewajiban memberikan dan menyampaikan Informasi Publik dilakukan paling singkat enam bulan sekali.</p>

<p style="text-align:justify">Kewajiban menyebarluaskan Informasi Publik disampaikan dengan cara yang mudah dijangkau oleh masyarakat dan dalam bahasa yang mudah dipahami, Cara-cara tersebut ditentukan lebih lanjut oleh Pejabat Pengelola Informasi dan Dokumentasi (PPID) di Badan Publik terkait. Ketentuan lebih lanjut mengenai kewajiban Badan Publik memberikan dan menyampaikan Informasi Publik secara berkala diatur dengan Petunjuk Teknis Komisi Informasi.</p>

<p style="text-align:justify">Sementara itu, untuk mewujudkan pelayanan cepat, tepat, dan sederhana setiap Badan Publik menunjuk PPID; dan membuat dan mengembangkan sistem penyediaan layanan informasi secara cepat, mudah, dan wajar sesuai dengan petunjuk teknis&nbsp; standar layanan Informasi Publik yang berlaku secara nasional. PPID dibantu oleh pejabat fungsional. Sebagai implementasi dari UU No. 14/2008, pemerintah menerbitkan PP No. 61/2010 tentang Pelaksanaan Undang-Undang Nomor 14 Tahun 2008 tentang Keterbukaan Informasi Publik. Sementara itu, sesuai PP No. 61/2010, PPID bertugas dan bertanggungjawab dalam hal, antara lain</p>

<ol style="list-style-type:lower-alpha">
  <li style="text-align:justify">penyediaan, penyimpanan, pendokumentasian, dan pengamanan informasi;</li>
  <li style="text-align:justify">pelayanan informasi sesuai dengan aturan yang berlaku;</li>
  <li style="text-align:justify">pelayanan informasi publik yang cepat, tepat, dan sederhana;</li>
  <li style="text-align:justify">penetapan prosedur operasional penyebarluasan informasi publik; selanjutnya;</li>
  <li style="text-align:justify">Pengujian konsekuensi;</li>
  <li style="text-align:justify">Pengklasifikasian informasi dan/atau pengubahannya;</li>
  <li style="text-align:justify">penetapan informasi yang dikecualikan yang telah habis jangka waktu pengecualiannya sebagai informasi publik yang dapat diakses; dan penetapan pertimbangan tertulis atas setiap kebijakan yang diambil untuk memenuhi hak setiap orang atas informasi publik. Selain ketentuan tersebut, PPID dapat menjalankan tugas dan tanggungjawabnya sesuai dengan ketentuan peraturan perundang-undangan.</li>
</ol>

<p style="text-align:justify">PPID di Kemendagri diketahui oleh Kepala Pusat Penerangan (Kapuspen) Kemendagri. Selain Kapuspen, juga ditetapkan pejabat penghubung pada masing-masing komponen (sekretariat) yang membidangi atau memiliki tanggungjawab terhadap pengelolaan data dan informasi. Khususnya di Ditjen Keuangan Daerah, PPID ditangani oleh Bagian Perencanaan Sesdijen Keuangan Daerah.</p>

<p style="text-align:justify">Dalam rangka pengelolaan informasi publik, Presiden juga mengeluarkan Inpres No. 17/2011 tentang Aksi Pencegahan dan Pemberantasan Korupsi Tahun 2012.Inpres tersebut mengamanatkan kepada seluruh Kementerian/Lembaga (K/L) serta pemerintah daerah terkait dengan upaya pencegahan korupsi.</p>

<p style="text-align:justify">Dalam rangka pelaksanaan Inpres tersebut, pemerintah telah menyusun rencana aksi nasional. Untuk pemerintah pusat, rencana aksi menjadi domain Kementerian Keuangan (Kemenkeu) terkait dengan transparansi pengelolaan anggaran K/L. Sedangkan untuk transparansi pengelolaan anggaran daerah (TPAD) dilaksanakan oleh Kemendagri. Instruksi tersebut dinilai cukup berat karena baru pertama kali dilakukan oleh Badan Publik, baik di pusat maupun daerah terkait dengan penganggaran. Dalam hal ini, UKP4 meminta Kemendagri untuk menyusun pedoman agar provinsi dan kab/kota menindaklanjuti UU No. 14/2008 serta Inpres No. 17/2011. Kemendagri telah menyelenggarakan rapat dengan&nbsp; UKP4 untuk mendorong daerah agar lebih transparan terhadap anggaran daerah.</p>

<p style="text-align:justify">Diakui, saat ini belum banyak daerah yang menyediakan anggaran untuk mendanai rencana aksi tersebut. Dalam rangka mendorong daerah untuk menyelenggarakan transparasi anggaran, Kemendagri telah mengeluarkan Instruksi Mendagri No. 188.52/1797/SC/2012 tentang Transparasi Pengelolaan Anggaran Daerah (TPAD). Instruksi tersebut ditujukan kepada gubernur seluruh Indonesia dalam rangka pelaksanaan TPAD. Instruksi Mendagri tersebut mengamanatkan pemerintah provinsi untuk menyiapkan menu content dengan nama TPAD dalam website resmi pemerintah provinsi (Pemprov). Pemprov juga perlu mempublikasikan data mutakhir Pemprov pada menu content yang terdiri dari 12 items.</p>

<p style="text-align:justify">Selanjutnya, Gubernur membuat Instruksi Gubernur yang ditujukan kepada bupati/walikota untuk menyiapkan menu content dengan nama TPAD dalam website resmi pemerintah kab/kota. Selain itu, Pemprov perlu melaksanakan monitoring dan evaluasi atas pelaksanaan Instruksi Gubernur tersebut. Pemprov juga berkoordinasi dengan bupati/walikota di wilayah masing-masing agar segara melakukan percepatan bagi daerah yang belum mengimplementasikan Instruksi Gubernur serta melaporkan perkembangan data dan menu content TPAD kepada Mendagri. Tahun 2013, UKP4 menetapkan rencana aksi di daerah.</p>

<p style="text-align:justify">Saat ini, UKP4 telah menetapkan daerah-daerah sebagai proyek percontohan (pilot project) pelaksanaan TAPD. Sebagai tahap awal, TAPD dilaksanakan di 99 daerah provinsi dan kab/kota, yakni 33 provinsi, 33 kabupaten, dan 33 kota. Dalam hal ini, daerah bertanggungjawab langsung terhadap UKP4 terkait penilaian terhadap rencana aksi daerah. Ditjen Keuangan Daerah berkewajiban membina TPAD pada 99 daerah (provinsi dan kab/kota). Tugas Kemendagri c.q. Ditjen Keuangan Daerah adalah mendorong daerah agar mulai melaksanakan TAPD, termasuk melakukan verifikasi atas rencana aksi yang sudah disepakati oleh UKP4 dan daerah</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
